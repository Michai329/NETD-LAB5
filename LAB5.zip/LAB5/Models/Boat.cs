﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LAB5.Models
{
    public class Boat
    {
        public int boatID { get; set; }

        public string make { get; set; }

        public string model { get; set; }

        public int year { get; set; }

        public int kilometers { get; set; }

    }
}
