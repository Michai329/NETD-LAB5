﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
namespace LAB5.Models
{
    public class BoatContext : DbContext
    {

        //Constructor for BoarContext
        public BoatContext(DbContextOptions<BoatContext> options) : base(options)
        {

        }
        public DbSet<Boat> Boats { get; set; }

    }
}
